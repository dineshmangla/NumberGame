﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace NumberGameMvcApp
{

    public class BL
    {
        string Connectionstring = string.Empty;
        string IsXml = string.Empty;

        public BL()
        {
            Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            IsXml = Common.IsXml();
        }

        public DataSet GetNumber(string TimeZone)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(Connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand("USP_GetNumber" + IsXml, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@TimeZone", TimeZone);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
            return ds;
        }

        public int AddPartyDetails(string json)
        {
            int iRow = 0;
            using (SqlConnection con = new SqlConnection(Connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand("USP_AddPartyDetails" + IsXml, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@json", json);
                    con.Open();
                    iRow = cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            return iRow;
        }

        public DataSet GetParty(string json)
        {
            DataSet ds = new DataSet();
            using (SqlConnection con = new SqlConnection(Connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand("CALL USP_GetParty" + IsXml + "(@_json);", con))
                {
                    cmd.Parameters.AddWithValue("@_json", json);
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(ds);
                    }
                }
            }
            return ds;
        }
    }
}