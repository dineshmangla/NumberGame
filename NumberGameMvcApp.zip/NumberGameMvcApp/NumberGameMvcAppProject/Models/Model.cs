﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NumberGameMvcApp.Models
{
    public class clsNumber
    {
        public string id { get; set; }
        public string name { get; set; }
        public string lastnumber { get; set; }
        public string lastshowtime { get; set; }
        public string nextnumber { get; set; }
        public string nextshowtime { get; set; }
        public string _TimeZoneDate { get; set; }
    }

    public class Login
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string HostName { get; set; }
        public string BrowserName { get; set; }
        public string MachineName { get; set; }
        public string MyIP { get; set; }
        public string isAdmin { get; set; }
    }

    public class Response
    {
        public string code { get; set; }
        public string message { get; set; }
    }
    
    public class Reset
    {
        public string UserName { get; set; }
        public string NewPassword { get; set; }
    }

    public class GetStock
    {
        public string partyId { get; set; }
        public string itemId { get; set; }
        public string brand { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string type { get; set; }
        public string quantity { get; set; }
        public string price { get; set; }
        public string value { get; set; }
        public string location { get; set; }
    }

    public class PartyDetails
    {
        public string id { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string contact { get; set; }
        public string gst { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string pincode { get; set; }
        public string username { get; set; }
    }

    public class ItemDetailsAuto
    {
        public int id { get; set; }
        public string label { get; set; }
        public string value { get; set; }
    }

    public class DeleteTransaction
    {
        public string id { get; set; }
        public string username { get; set; }
    }

    public class GetTransactions
    {
        public string id { get; set; }
        public string TransactionDateFrom { get; set; }
        public string TransactionDateTo { get; set; }
        public string partyId { get; set; }
        public string number { get; set; }
        public string transactionDate { get; set; }
        public string insertedOn { get; set; }
        public string username { get; set; }
    }

    public class Transactions
    {
        public string itemId { get; set; }
        public string type { get; set; }
        public string qty { get; set; }
        public string remarks { get; set; }
    }

    public class ItemDetails
    {
        public string id { get; set; }
        public string name { get; set; }
    }
}