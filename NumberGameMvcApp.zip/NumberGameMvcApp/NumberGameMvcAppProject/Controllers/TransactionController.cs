﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.Xml;
using System.Xml.Linq;
using System.Text;
using System.IO;
using NumberGameMvcApp.Models;
using System.Data.SqlClient;

namespace NumberGameMvcApp.Controllers
{
    public class TransactionController : Controller
    {
        string IsXml = string.Empty;
        List<ItemDetails> listItemDetails;
        List<ItemDetailsAuto> listItemDetailsAuto;
        
        public ActionResult Add(string Operation = "")
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            ViewBag.Operation = Operation;
            return View();
        }

        public ActionResult Details()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        public ActionResult DetailsHistory()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        [HttpGet]
        public string GetPartyDetails()
        {
            List<PartyDetails> lstPartyDetails = new List<PartyDetails>();
            string details = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("CALL USP_GetPartyDetails();", Connectionstring);
                da.Fill(ds);
                lstPartyDetails = ds.Tables[0].AsEnumerable().Select(x => new PartyDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                details = JsonConvert.SerializeObject(lstPartyDetails);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }

            return details;
        }

        [HttpGet]
        public string GetItemDetails()
        {
            List<ItemDetails> lstItemDetails = new List<ItemDetails>();
            string details = string.Empty;
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("CALL USP_GetItemDetails();", Connectionstring);
                da.Fill(ds);
                lstItemDetails = ds.Tables[0].AsEnumerable().Select(x => new ItemDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                listItemDetails = lstItemDetails;
                details = JsonConvert.SerializeObject(lstItemDetails);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
            return details;
        }

        [HttpGet]
        public string GetItemDetailsAuto()
        {
            List<ItemDetailsAuto> lstItemDetailsAuto = new List<ItemDetailsAuto>();
            string details = string.Empty;
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("CALL USP_GetItemDetails();", Connectionstring);
                da.Fill(ds);
                lstItemDetailsAuto = ds.Tables[0].AsEnumerable().Select(x => new ItemDetailsAuto { id = Convert.ToInt32(x["id"]), label = Convert.ToString(x["name"]), value = Convert.ToString(x["name"]), }).ToList();
                listItemDetailsAuto = lstItemDetailsAuto;
                details = JsonConvert.SerializeObject(lstItemDetailsAuto);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
            return details;
        }

        [HttpGet]
        public string GetUserDetails()
        {
            List<PartyDetails> lstPartyDetails = new List<PartyDetails>();
            string details = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("CALL USP_GetUserDetails();", Connectionstring);
                da.Fill(ds);
                lstPartyDetails = ds.Tables[0].AsEnumerable().Select(x => new PartyDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                details = JsonConvert.SerializeObject(lstPartyDetails);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }

            return details;
        }

        [HttpGet]
        public string GetLocationDetails()
        {
            List<ItemDetails> lstItemDetails = new List<ItemDetails>();
            string details = string.Empty;
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("CALL USP_GetLocationDetails();", Connectionstring);
                da.Fill(ds);
                lstItemDetails = ds.Tables[0].AsEnumerable().Select(x => new ItemDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                details = JsonConvert.SerializeObject(lstItemDetails);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }
            return details;
        }

        [HttpPost]
        public string AddTransactionDetails(GetTransactions objGetTransactions)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            int iRow = 0;
            string error = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objGetTransactions);
                else
                    _json = Common.ToXML(objGetTransactions);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_AddTransactionDetails" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        con.Open();
                        //iRow = 10;
                        iRow = cmd.ExecuteNonQuery();
                        objResponse.code = "200";
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                error = ex.Message;
            }

            objResponse.message = iRow > 0 ? "Success" : "Fail " + error;
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpPost]
        public string GetTransactionDetails(GetTransactions objGetTransactions)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            List<GetTransactions> lstGetTransactions = new List<GetTransactions>();
            string response = string.Empty;
            DataSet ds = new DataSet();
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objGetTransactions);
                else
                    _json = Common.ToXML(objGetTransactions);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetTransactionDetails" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(ds);
                            lstGetTransactions = ds.Tables[0].AsEnumerable().Select(x => new GetTransactions
                            {
                                id = Convert.ToString(x["id"]),
                                partyId = Convert.ToString(x["partyId"]),
                                number = Convert.ToString(x["number"]),
                                transactionDate = Convert.ToString(x["showtime"]),
                                insertedOn = Convert.ToDateTime(x["insertedOn"]).ToString("yyyy-MM-dd hh:mm:ss"),
                                username = Convert.ToString(x["username"]),
                            }).ToList();
                            objResponse.code = "200";
                            objResponse.message = JsonConvert.SerializeObject(lstGetTransactions);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }

            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpPost]
        public string UpdateTransactionDetails(GetTransactions objGetTransactions)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            List<GetTransactions> lstGetTransactions = new List<GetTransactions>();
            string response = string.Empty;
            DataSet ds = new DataSet();
            int iRows = 0;
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objGetTransactions);
                else
                    _json = Common.ToXML(objGetTransactions);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_UpdateTransactionDetails" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        con.Open();
                        iRows = cmd.ExecuteNonQuery();
                        con.Close();
                        objResponse.code = "200";
                        objResponse.message = iRows.ToString() + " record(s) updated successfully";

                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }

            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }
        [HttpPost]
        public string DeleteTransactions(DeleteTransaction objDeleteTransaction)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            int iRow = 0;
            string error = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objDeleteTransaction);
                else
                    _json = Common.ToXML(objDeleteTransaction);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_DeleteTransactions" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        con.Open();
                        iRow = cmd.ExecuteNonQuery();
                        objResponse.code = "200";
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                error = ex.Message;
            }

            objResponse.message = iRow > 0 ? "Success" : "Fail " + error;
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }
        
        [HttpPost]
        public string Export(string HtmlTable)
        {
            Response objResponse = new Response();
            string response = string.Empty;
            string prefix = string.Empty;
            try
            {
                prefix = HtmlTable.Substring(0, HtmlTable.IndexOf('<'));
                HtmlTable = HtmlTable.Replace(prefix, "");
                prefix = prefix.Replace("\n", "").Trim();
                DateTime dateTime = DateTime.Now;
                string filename = prefix + "_" + dateTime.ToString("yyyyMMdd_HHmmss_") + dateTime.Ticks.ToString() + ".CSV";
                string fileLoc = Path.GetTempPath() + filename;
                string strCSV = ExportCSV(HtmlTable).ToString();

                using (FileStream fs = System.IO.File.Create(fileLoc))
                {
                }
                using (StreamWriter sw = new StreamWriter(fileLoc))
                {
                    sw.Write(strCSV);
                }
                objResponse.code = "200";
                objResponse.message = filename;
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }
            
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpGet]
        public ActionResult Download(string file)
        {
            string fullPath = Path.GetTempPath() + file;
            return File(fullPath, "application/vnd.ms-excel", file);
        }

        private StringBuilder ExportCSV(string HtmlTable)
        {
            XDocument doc = XDocument.Parse(HtmlTable);
            StringBuilder sb = new StringBuilder(HtmlTable.Length + 100000);
            foreach (XElement node in doc.Descendants("tr"))
            {
                foreach (XElement innerNode in node.Elements())
                {
                    if (innerNode.Value.ToString().ToLower() == "action" || innerNode.Value.ToString().ToLower() == "delete")
                        continue;
                    sb.AppendFormat("\"{0}\",", innerNode.Value);
                }
                sb.Remove(sb.Length - 1, 1);
                sb.AppendLine();
            }
            return sb;
        }

        public ActionResult Item()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }
    }
}
