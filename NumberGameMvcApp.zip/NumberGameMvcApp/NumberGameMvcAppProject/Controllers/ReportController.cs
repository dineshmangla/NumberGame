﻿using Newtonsoft.Json;
using NumberGameMvcApp.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;

namespace NumberGameMvcApp.Controllers
{
    public class ReportController : Controller
    {
        string IsXml = string.Empty;
        public ActionResult Stock()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        [HttpPost]
        public string GetItemStock(GetStock objGetStock)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            List<GetStock> lstGetStock = new List<GetStock>();
            string response = string.Empty;
            DataSet ds = new DataSet();
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objGetStock);
                else
                    _json = Common.ToXML(objGetStock);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("CALL USP_GetStock" + IsXml + "(@_json);", con))
                    {
                        cmd.Parameters.AddWithValue("@_json", _json);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(ds);
                            lstGetStock = ds.Tables[0].AsEnumerable().Select(x => new GetStock
                            {
                                partyId = Convert.ToString(x["partyId"]),
                                itemId = Convert.ToString(x["itemId"]),
                                brand = Convert.ToString(x["brand"]),
                                name = Convert.ToString(x["name"]),
                                description = Convert.ToString(x["description"]),
                                type = Convert.ToString(x["type"]),
                                quantity = Convert.ToString(x["quantity"]),
                                price = Convert.ToString(x["price"]),
                                value = Convert.ToString(x["value"]),
                                location = Convert.ToString(x["location"]),
                            }).ToList();
                            objResponse.code = "200";
                            objResponse.message = JsonConvert.SerializeObject(lstGetStock);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }

            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }
    }
}
