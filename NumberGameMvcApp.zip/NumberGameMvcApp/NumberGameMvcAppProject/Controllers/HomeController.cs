﻿using Newtonsoft.Json;
using NumberGameMvcApp.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace NumberGameMvcApp.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public string GetNumber()
        {
            List<clsNumber> lstclsNumber = new List<clsNumber>();
            string response = string.Empty;
            Response objResponse = new Response();
            BL objBL = new BL();
            DataSet ds = new DataSet();
            try
            {
                string TimeZone = Convert.ToString(TimeZoneInfo.Local.GetUtcOffset(DateTime.UtcNow).TotalMinutes);
                ds = objBL.GetNumber(TimeZone);
                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        clsNumber objclsNumber = new clsNumber();
                        objclsNumber.id = Convert.ToString(dr["id"]);
                        objclsNumber.name = Convert.ToString(dr["name"]);
                        objclsNumber.lastnumber = Convert.ToString(dr["lastnumber"]);
                        objclsNumber.lastshowtime = Convert.ToString(dr["lastshowtime"]);
                        objclsNumber.nextnumber = Convert.ToString(dr["nextnumber"]);
                        objclsNumber.nextshowtime = Convert.ToDateTime(dr["nextshowtime"]).ToString("hh:mm tt");
                        objclsNumber._TimeZoneDate = Convert.ToString(dr["_TimeZoneDate"]);
                        lstclsNumber.Add(objclsNumber);
                    }
                    objResponse.code = "200";
                    objResponse.message = JsonConvert.SerializeObject(lstclsNumber);
                }
                else
                {
                    objResponse.code = "100";
                    objResponse.message = "No Data Found";
                }
            }
            catch (Exception ex)
            {
                string error = ex.Message;
                objResponse.code = "100";
                objResponse.message = error;
            }
            response = JsonConvert.SerializeObject(objResponse);

            return response;
        }

    }
}
