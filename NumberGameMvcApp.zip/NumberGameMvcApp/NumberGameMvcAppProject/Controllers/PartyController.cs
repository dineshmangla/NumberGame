﻿using Newtonsoft.Json;
using NumberGameMvcApp.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;

namespace NumberGameMvcApp.Controllers
{
    public class PartyController : Controller
    {
        string IsXml = string.Empty;

        public ActionResult Add()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        [HttpPost]
        public string AddPartyDetails(PartyDetails objPartyDetails)
        {
            Response objResponse = new Response();
            string response = string.Empty;
            int iRow = 0;
            string error = string.Empty;
            BL objBL = new BL();
            try
            {
                string json = JsonConvert.SerializeObject(objPartyDetails);
                iRow = objBL.AddPartyDetails(json);
                objResponse.code = "200";
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                error = ex.Message;
            }
            
            objResponse.message = iRow > 0 ? "Success" : "Fail " + error;
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpPost]
        public string GetParty(PartyDetails objPartyDetails)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            string error = string.Empty;
            DataSet ds = new DataSet();
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objPartyDetails);
                else
                    _json = Common.ToXML(objPartyDetails);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetParty" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(ds);
                            objPartyDetails.name = Convert.ToString(ds.Tables[0].Rows[0]["name"]);
                            objPartyDetails.address = Convert.ToString(ds.Tables[0].Rows[0]["address"]);
                            objPartyDetails.contact = Convert.ToString(ds.Tables[0].Rows[0]["contact"]);
                            objPartyDetails.gst = Convert.ToString(ds.Tables[0].Rows[0]["gst"]);
                            objPartyDetails.city = Convert.ToString(ds.Tables[0].Rows[0]["city"]);
                            objPartyDetails.state = Convert.ToString(ds.Tables[0].Rows[0]["state"]);
                            objPartyDetails.pincode = Convert.ToString(ds.Tables[0].Rows[0]["pincode"]);
                            objResponse.code = "200";
                            objResponse.message = JsonConvert.SerializeObject(objPartyDetails);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpGet]
        public string GetPartyDetails()
        {
            List<PartyDetails> lstPartyDetails = new List<PartyDetails>();
            string details = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("USP_GetPartyDetails", Connectionstring);
                da.Fill(ds);
                lstPartyDetails = ds.Tables[0].AsEnumerable().Select(x => new PartyDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                details = JsonConvert.SerializeObject(lstPartyDetails);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }

            return details;
        }

    }
}
