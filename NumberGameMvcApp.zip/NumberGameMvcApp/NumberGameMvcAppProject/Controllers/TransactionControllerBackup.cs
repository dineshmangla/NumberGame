﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.Xml;
using System.Xml.Linq;
using System.Text;
using System.IO;

namespace StockMvcApp.Controllers
{
    public class TransactionController : Controller
    {
        string IsXml = string.Empty;
        List<ItemDetails> listItemDetails;
        List<ItemDetailsAuto> listItemDetailsAuto;
        public class ItemDetailsAuto
        {
            public int id { get; set; }
            public string label { get; set; }
            public string value { get; set; }
        }

        public class DeleteTransaction
        {
            public string id { get; set; }
            public string username { get; set; }
        }

        public class GetTransactions
        {
            public string id { get; set; }
            public string TransactionDateFrom { get; set; }
            public string TransactionDateTo { get; set; }
            public string documentNo { get; set; }
            public string partyId { get; set; }
            public string itemId { get; set; }
            public string brand { get; set; }
            public string name { get; set; }
            public string description { get; set; }
            public string type { get; set; }
            public string remarks { get; set; }
            public string quantity { get; set; }
            public string transactionType { get; set; }
            public string transactionDate { get; set; }
            public string insertedOn { get; set; }
            public string username { get; set; }
            public string location { get; set; }
            public string price { get; set; }
            public string value { get; set; }
        }

        public class TransactionDetails
        {
            public string Operation { get; set; }
            public string TransactionDate { get; set; }
            public string partyId { get; set; }
            public string documentNo { get; set; }
            public string username { get; set; }
            public List<Transactions> transactions { get; set; }
        }

        public class Transactions
        {
            public string itemId { get; set; }
            public string type { get; set; }
            public string qty { get; set; }
            public string remarks { get; set; }
        }

        public class Response
        {
            public string code { get; set; }
            public string message { get; set; }
        }

        public class ItemDetails
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public class PartyDetails
        {
            public string id { get; set; }
            public string name { get; set; }
        }

        public ActionResult Add(string Operation = "")
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            ViewBag.Operation = Operation;
            return View();
        }

        public ActionResult Details()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        [HttpGet]
        public string GetPartyDetails()
        {
            List<PartyDetails> lstPartyDetails = new List<PartyDetails>();
            string details = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["StockConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                MySqlDataAdapter da = new MySqlDataAdapter("CALL USP_GetPartyDetails();", Connectionstring);
                da.Fill(ds);
                lstPartyDetails = ds.Tables[0].AsEnumerable().Select(x => new PartyDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                details = JsonConvert.SerializeObject(lstPartyDetails);
            }
            catch (Exception ex)
            {
            }

            return details;
        }

        [HttpGet]
        public string GetItemDetails()
        {
            List<ItemDetails> lstItemDetails = new List<ItemDetails>();
            string details = string.Empty;
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["StockConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                MySqlDataAdapter da = new MySqlDataAdapter("CALL USP_GetItemDetails();", Connectionstring);
                da.Fill(ds);
                lstItemDetails = ds.Tables[0].AsEnumerable().Select(x => new ItemDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                listItemDetails = lstItemDetails;
                details = JsonConvert.SerializeObject(lstItemDetails);
            }
            catch (Exception ex)
            {

            }
            return details;
        }

        [HttpGet]
        public string GetItemDetailsAuto()
        {
            List<ItemDetailsAuto> lstItemDetailsAuto = new List<ItemDetailsAuto>();
            string details = string.Empty;
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["StockConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                MySqlDataAdapter da = new MySqlDataAdapter("CALL USP_GetItemDetails();", Connectionstring);
                da.Fill(ds);
                lstItemDetailsAuto = ds.Tables[0].AsEnumerable().Select(x => new ItemDetailsAuto { id = Convert.ToInt32(x["id"]), label = Convert.ToString(x["name"]), value = Convert.ToString(x["name"]), }).ToList();
                listItemDetailsAuto = lstItemDetailsAuto;
                details = JsonConvert.SerializeObject(lstItemDetailsAuto);
            }
            catch (Exception ex)
            {

            }
            return details;
        }

        [HttpGet]
        public string GetUserDetails()
        {
            List<PartyDetails> lstPartyDetails = new List<PartyDetails>();
            string details = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["StockConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                MySqlDataAdapter da = new MySqlDataAdapter("CALL USP_GetUserDetails();", Connectionstring);
                da.Fill(ds);
                lstPartyDetails = ds.Tables[0].AsEnumerable().Select(x => new PartyDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                details = JsonConvert.SerializeObject(lstPartyDetails);
            }
            catch (Exception ex)
            {
            }

            return details;
        }

        [HttpGet]
        public string GetLocationDetails()
        {
            List<ItemDetails> lstItemDetails = new List<ItemDetails>();
            string details = string.Empty;
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["StockConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                MySqlDataAdapter da = new MySqlDataAdapter("CALL USP_GetLocationDetails();", Connectionstring);
                da.Fill(ds);
                lstItemDetails = ds.Tables[0].AsEnumerable().Select(x => new ItemDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                details = JsonConvert.SerializeObject(lstItemDetails);
            }
            catch (Exception ex)
            {

            }
            return details;
        }

        [HttpPost]
        public string AddTransactionDetails(TransactionDetails objTransactionDetails)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            int iRow = 0;
            string error = string.Empty;

            if (objTransactionDetails.Operation != null && objTransactionDetails.Operation == "Dispatch Transaction Add")
                objTransactionDetails.Operation = "-1";
            else
                objTransactionDetails.Operation = "1";

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["StockConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objTransactionDetails);
                else
                    _json = Common.ToXML(objTransactionDetails);
                using (MySqlConnection con = new MySqlConnection(Connectionstring))
                {
                    using (MySqlCommand cmd = new MySqlCommand("CALL USP_AddTransactionDetails" + IsXml + "(@_json);", con))
                    {
                        cmd.Parameters.AddWithValue("@_json", _json);
                        con.Open();
                        //iRow = 10;
                        iRow = cmd.ExecuteNonQuery();
                        objResponse.code = "200";
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                error = ex.Message;
            }

            objResponse.message = iRow > 0 ? "Success" : "Fail " + error;
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpPost]
        public string GetTransactionDetails(GetTransactions objGetTransactions)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            List<GetTransactions> lstGetTransactions = new List<GetTransactions>();
            string response = string.Empty;
            DataSet ds = new DataSet();
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["StockConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objGetTransactions);
                else
                    _json = Common.ToXML(objGetTransactions);
                using (MySqlConnection con = new MySqlConnection(Connectionstring))
                {
                    using (MySqlCommand cmd = new MySqlCommand("CALL USP_GetTransactionDetails" + IsXml + "(@_json);", con))
                    {
                        cmd.Parameters.AddWithValue("@_json", _json);
                        using (MySqlDataAdapter da = new MySqlDataAdapter(cmd))
                        {
                            da.Fill(ds);
                            lstGetTransactions = ds.Tables[0].AsEnumerable().Select(x => new GetTransactions
                            {
                                id = Convert.ToString(x["id"]),
                                partyId = Convert.ToString(x["partyId"]),
                                itemId = Convert.ToString(x["itemId"]),
                                brand = Convert.ToString(x["brand"]),
                                name = Convert.ToString(x["name"]),
                                description = Convert.ToString(x["description"]),
                                type = Convert.ToString(x["type"]),
                                quantity = Convert.ToString(x["quantity"]),
                                remarks = Convert.ToString(x["remarks"]),
                                transactionDate = Convert.ToString(x["transactionDate"]),
                                transactionType = Convert.ToString(x["transactionType"]),
                                insertedOn = Convert.ToDateTime(x["insertedOn"]).ToString("yyyy-MM-dd hh:mm:ss"),
                                username = Convert.ToString(x["username"]),
                                location = Convert.ToString(x["location"]),
                                documentNo = Convert.ToString(x["documentNo"]),
                                price = Convert.ToString(x["price"]),
                                value = Convert.ToString(x["value"]),
                            }).ToList();
                            objResponse.code = "200";
                            objResponse.message = JsonConvert.SerializeObject(lstGetTransactions);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }

            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpPost]
        public string DeleteTransactions(DeleteTransaction objDeleteTransaction)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            int iRow = 0;
            string error = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["StockConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objDeleteTransaction);
                else
                    _json = Common.ToXML(objDeleteTransaction);
                using (MySqlConnection con = new MySqlConnection(Connectionstring))
                {
                    using (MySqlCommand cmd = new MySqlCommand("CALL USP_DeleteTransactions" + IsXml + "(@_json);", con))
                    {
                        cmd.Parameters.AddWithValue("@_json", _json);
                        con.Open();
                        iRow = cmd.ExecuteNonQuery();
                        objResponse.code = "200";
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                error = ex.Message;
            }

            objResponse.message = iRow > 0 ? "Success" : "Fail " + error;
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }
        
        [HttpPost]
        public string Export(string HtmlTable)
        {
            Response objResponse = new Response();
            string response = string.Empty;
            string prefix = string.Empty;
            try
            {
                prefix = HtmlTable.Substring(0, HtmlTable.IndexOf('<'));
                HtmlTable = HtmlTable.Replace(prefix, "");
                prefix = prefix.Replace("\n", "").Trim();
                DateTime dateTime = DateTime.Now;
                string filename = prefix + "_" + dateTime.ToString("yyyyMMdd_HHmmss_") + dateTime.Ticks.ToString() + ".CSV";
                string fileLoc = Path.GetTempPath() + filename;
                string strCSV = ExportCSV(HtmlTable).ToString();

                using (FileStream fs = System.IO.File.Create(fileLoc))
                {
                }
                using (StreamWriter sw = new StreamWriter(fileLoc))
                {
                    sw.Write(strCSV);
                }
                objResponse.code = "200";
                objResponse.message = filename;
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }
            
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpGet]
        public ActionResult Download(string file)
        {
            string fullPath = Path.GetTempPath() + file;
            return File(fullPath, "application/vnd.ms-excel", file);
        }

        private StringBuilder ExportCSV(string HtmlTable)
        {
            XDocument doc = XDocument.Parse(HtmlTable);
            StringBuilder sb = new StringBuilder(HtmlTable.Length + 100000);
            foreach (XElement node in doc.Descendants("tr"))
            {
                foreach (XElement innerNode in node.Elements())
                {
                    if (innerNode.Value.ToString().ToLower() == "action" || innerNode.Value.ToString().ToLower() == "delete")
                        continue;
                    sb.AppendFormat("\"{0}\",", innerNode.Value);
                }
                sb.Remove(sb.Length - 1, 1);
                sb.AppendLine();
            }
            return sb;
        }

        public ActionResult Item()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }
    }
}
