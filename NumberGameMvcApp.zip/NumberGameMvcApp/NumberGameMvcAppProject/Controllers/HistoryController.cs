﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using System.Xml;
using System.Xml.Linq;
using System.Text;
using System.IO;
using NumberGameMvcApp.Models;
using System.Data.SqlClient;

namespace NumberGameMvcApp.Controllers
{
    public class HistoryController : Controller
    {
        string IsXml = string.Empty;
        
        public ActionResult Details()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        [HttpPost]
        public string GetTransactionDetails(GetTransactions objGetTransactions)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            List<GetTransactions> lstGetTransactions = new List<GetTransactions>();
            string response = string.Empty;
            DataSet ds = new DataSet();
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objGetTransactions);
                else
                    _json = Common.ToXML(objGetTransactions);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetHistoryDetails" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(ds);
                            lstGetTransactions = ds.Tables[0].AsEnumerable().Select(x => new GetTransactions
                            {
                                id = Convert.ToString(x["id"]),
                                partyId = Convert.ToString(x["partyId"]),
                                number = Convert.ToString(x["number"]),
                                transactionDate = Convert.ToString(x["showtime"]),
                                insertedOn = Convert.ToDateTime(x["insertedOn"]).ToString("yyyy-MM-dd hh:mm:ss"),
                                username = Convert.ToString(x["username"]),
                            }).ToList();
                            objResponse.code = "200";
                            objResponse.message = JsonConvert.SerializeObject(lstGetTransactions);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }

            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }
    }
}
