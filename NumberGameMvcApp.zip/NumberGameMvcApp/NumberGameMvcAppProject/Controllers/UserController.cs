﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Newtonsoft.Json;
using NumberGameMvcApp.Models;
using System.Data;
using System.Data.Odbc;
using System.Data.SqlClient;

namespace NumberGameMvcApp.Controllers
{
    public class UserController : Controller
    {
        string strTempKey = "numbergameapp";

        string IsXml = string.Empty;

        public class UserDetails
        {
            public string id { get; set; }
            public string name { get; set; }
            public string password { get; set; }
            public string location { get; set; }
            public string isadmin { get; set; }
            public string isdeleted { get; set; }
            public string username { get; set; }
        }
        
        public string Encrypt(string input)
        {
            TripleDESCryptoServiceProvider objDESCrypto =
            new TripleDESCryptoServiceProvider();
            MD5CryptoServiceProvider objHashMD5 = new MD5CryptoServiceProvider();
            byte[] byteHash, byteBuff;
            byteHash = objHashMD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(strTempKey));
            objHashMD5 = null;
            objDESCrypto.Key = byteHash;
            objDESCrypto.Mode = CipherMode.ECB; //CBC, CFB
            byteBuff = ASCIIEncoding.ASCII.GetBytes(input);
            return Convert.ToBase64String(objDESCrypto.CreateEncryptor().TransformFinalBlock(byteBuff, 0, byteBuff.Length));
        }

        public string Decrypt(string input)
        {
            TripleDESCryptoServiceProvider objDESCrypto =
            new TripleDESCryptoServiceProvider();
            MD5CryptoServiceProvider objHashMD5 = new MD5CryptoServiceProvider();
            byte[] byteHash, byteBuff;
            byteHash = objHashMD5.ComputeHash(ASCIIEncoding.ASCII.GetBytes(strTempKey));
            objHashMD5 = null;
            objDESCrypto.Key = byteHash;
            objDESCrypto.Mode = CipherMode.ECB; //CBC, CFB
            byteBuff = Convert.FromBase64String(input);
            string strDecrypted = ASCIIEncoding.ASCII.GetString
            (objDESCrypto.CreateDecryptor().TransformFinalBlock
            (byteBuff, 0, byteBuff.Length));
            objDESCrypto = null;
            return strDecrypted;
        }
        
        public ActionResult Login(Login objLogin)
        {
            Session["UserName"] = null;
            return View();
        }

        public ActionResult Index()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        public ActionResult Reset()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        public ActionResult Add()
        {
            if (Session["UserName"] == null)
                return RedirectToAction("Login", "User");
            return View();
        }

        private Response IsValidUser(Login objLogin)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            string error = string.Empty;
            DataSet ds = new DataSet();
            objLogin.Password = Encrypt(objLogin.Password);
            //objLogin.Password = Decrypt(objLogin.Password);
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objLogin);
                else
                    _json = Common.ToXML(objLogin);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_IsValidUser" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            con.Open();
                            da.Fill(ds);
                            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                            {
                                objResponse.code = "200";
                                objResponse.message = Convert.ToString(ds.Tables[0].Rows[0]["isAdmin"]);
                            }
                            con.Close();
                        }
                    }
                }
            }
            catch (SqlException e)
            {
                objResponse.code = "100";
                objResponse.message = e.Message;
                switch (e.Number)
                {
                    case 0:
                        objResponse.message = "Cannot connect to database server.  Contact administrator";
                        break;
                    case 1045:
                        objResponse.message = "Invalid database username/password, please try again";
                        break;
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }
            //response = JsonConvert.SerializeObject(objResponse);
            //return response;
            return objResponse;
        }

        public ActionResult Logout(Login objLogin)
        {
            IsXml = Common.IsXml();
            Session["UserName"] = null;
            Session["isAdmin"] = null;
            return View("Login");
        }
        
        [HttpPost]
        public string AddUserDetails(UserDetails objUserDetails)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            int iRow = 0;
            string error = string.Empty;
            objUserDetails.password = Encrypt(objUserDetails.password);
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objUserDetails);
                else
                    _json = Common.ToXML(objUserDetails);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_AddUserDetails" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        con.Open();
                        iRow = cmd.ExecuteNonQuery();
                        objResponse.code = "200";
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                error = ex.Message;
            }
            objResponse.message = iRow > 0 ? "Success" : "Fail " + error;
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpPost]
        public string GetUser(UserDetails objUserDetails)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            string error = string.Empty;
            DataSet ds = new DataSet();
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objUserDetails);
                else
                    _json = Common.ToXML(objUserDetails);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("USP_GetUser" + IsXml, con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@json", _json);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            da.Fill(ds);
                            objUserDetails.name = Convert.ToString(ds.Tables[0].Rows[0]["name"]);
                            objUserDetails.password = Decrypt(Convert.ToString(ds.Tables[0].Rows[0]["password"]));
                            objUserDetails.location = Convert.ToString(ds.Tables[0].Rows[0]["location"]);
                            objUserDetails.isadmin = Convert.ToString(ds.Tables[0].Rows[0]["isadmin"]);
                            objUserDetails.isdeleted = Convert.ToString(ds.Tables[0].Rows[0]["isdeleted"]);
                            objResponse.code = "200";
                            objResponse.message = JsonConvert.SerializeObject(objUserDetails);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                objResponse.message = ex.Message;
            }

            response = JsonConvert.SerializeObject(objResponse);
            return response;

        }

        [HttpPost]
        public string Reset(Reset objReset)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Response();
            string response = string.Empty;
            int iRow = 0;
            string error = string.Empty;
            objReset.NewPassword = Encrypt(objReset.NewPassword);
            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            try
            {
                string _json = string.Empty;
                if (string.IsNullOrEmpty(IsXml))
                    _json = JsonConvert.SerializeObject(objReset);
                else
                    _json = Common.ToXML(objReset);
                using (SqlConnection con = new SqlConnection(Connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand("CALL USP_ResetPassword" + IsXml + "(@_json);", con))
                    {
                        cmd.Parameters.AddWithValue("@_json", _json);
                        con.Open();
                        iRow = cmd.ExecuteNonQuery();
                        objResponse.code = "200";
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.code = "100";
                error = ex.Message;
            }
            objResponse.message = iRow > 0 ? "Success" : "Fail " + error;
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpPost]
        public string LoginUser(Login objLogin)
        {
            IsXml = Common.IsXml();
            Response objResponse = new Models.Response();
            string response = string.Empty;
            if (string.IsNullOrEmpty(objLogin.UserName)
                || string.IsNullOrEmpty(objLogin.Password))
            {
                Session["UserName"] = null;
                RedirectToAction("Login", "User");
            }
            else
            {

                string MainUserName = System.Configuration.ConfigurationManager.AppSettings["MainUserName"].ToString();
                string MainPassword = System.Configuration.ConfigurationManager.AppSettings["MainPassword"].ToString();
                string ReportUserName = System.Configuration.ConfigurationManager.AppSettings["ReportUserName"].ToString();
                string ReportPassword = System.Configuration.ConfigurationManager.AppSettings["ReportPassword"].ToString();

                System.Web.HttpContext context = System.Web.HttpContext.Current;
                objLogin.MyIP = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
                if (objLogin.MyIP == "" || objLogin.MyIP == null)
                    objLogin.MyIP = Request.ServerVariables["REMOTE_ADDR"];
                objLogin.HostName = Dns.GetHostEntry(Dns.GetHostName()).HostName.ToString();
                objLogin.BrowserName = context.Request.Browser.Browser;

                objResponse = IsValidUser(objLogin);
                if (objResponse.code == "200")
                {
                    Session["UserName"] = objLogin.UserName;
                    Session["isAdmin"] = objResponse.message;
                    //RedirectToAction("Details", "Transaction");
                }
            }
            response = JsonConvert.SerializeObject(objResponse);
            return response;
        }

        [HttpGet]
        public string GetUserDetails()
        {
            List<PartyDetails> lstPartyDetails = new List<PartyDetails>();
            string details = string.Empty;

            string Connectionstring = Convert.ToString(ConfigurationManager.ConnectionStrings["DBConnectionString"]);
            DataSet ds = new DataSet();
            try
            {
                SqlDataAdapter da = new SqlDataAdapter("USP_GetUserDetails", Connectionstring);
                da.Fill(ds);
                lstPartyDetails = ds.Tables[0].AsEnumerable().Select(x => new PartyDetails { id = Convert.ToString(x["id"]), name = Convert.ToString(x["name"]), }).ToList();
                details = JsonConvert.SerializeObject(lstPartyDetails);
            }
            catch (Exception ex)
            {
                string error = ex.Message;
            }

            return details;
        }
    }
}
